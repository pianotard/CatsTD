import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) { 
        System.out.println("Welcome to image rotator!");
        System.out.println("Please key in your working directory (default: src)");
        Scanner sc = new Scanner(System.in);
        String directory = sc.next() + "/";
        System.out.println("Please key in your file name (include extension):");
        String input = sc.next();
        Rotator rotator = new Rotator(directory + input);
        System.out.println("Rotator created, choose dimensions (width x height):");
        int width = sc.nextInt();
        int height = sc.nextInt();
        rotator.setDimension(width, height);
        System.out.println("Rotator set to " + width + " x " + height);
        System.out.println("Type anything to start..");
        sc.next();
        String output = input.substring(0, input.length() - 4);
        for (int i = 0; i < 360; i++) {
            String name = directory + output + "/" + output + "_" + i + ".png";
            rotator.write(rotator.rotate(i), name);
            System.out.println("Written '" + name + "'");
        }
        System.out.println("Finished writing!");
    }
}
