import java.awt.Point;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.AffineTransformOp;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Rotator {

    BufferedImage source;

    public Rotator(String inputPath) {
        try {
            this.source = ImageIO.read(new File(inputPath));
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public void write(BufferedImage image, String outputPath) {
        File outputFile = new File(outputPath);
        try {
            ImageIO.write(image, "png", outputFile);
        } catch (IOException e) {
            System.err.println(e);
        }
    }

    public BufferedImage rotate(int degree) {
        AffineTransform at = new AffineTransform();
        double rad = Math.toRadians(degree);
        double sin = Math.abs(Math.sin(rad));
        double cos = Math.abs(Math.cos(rad));
        double w = this.source.getWidth();
        double h = this.source.getHeight();
        int dw = (int) Math.floor(w * cos + h * sin);
        int dh = (int) Math.floor(h * cos + w * sin);

        at.translate((dw - w) / 2, (dh - h) / 2);
        at.rotate(rad, w / 2, h / 2);

        BufferedImage ret = new BufferedImage(dw, dh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = ret.createGraphics();

        g2d.setTransform(at);

        g2d.drawImage(this.source, 0, 0, null);
        g2d.dispose();

        return ret;
    }

    public boolean setDimension(int width, int height) {
        this.source = UIUtil.resize(this.source, width, height);
        return true;
    }
}
